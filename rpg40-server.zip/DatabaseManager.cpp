#include "DatabaseManager.hpp"

// All implementations are in the header for this simple class.
// If you were to build a more complex connection pool,
// you would add the logic here.